#include<iostream>
#include<stdlib.h>
using namespace std;

struct node
{
	char data;
	int label;
	node *left, *right;
};

class dag
{
	int R[10];
	int top;
	char *op;

public:

	void init_stack(node *root)
	{
		top = root->label - 1;
		int temp = top;
		for (int i = 0; i <= top; i++)
		{
			R[i] = temp;
			temp--;
		}
	}

	void swap()
	{
		int temp = R[0];
		R[0] = R[1];
		R[1] = temp;
	}

	void findleafnodelabel(node *tree, int val)
	{
		if (tree->left != NULL && tree->right != NULL)
		{
			findleafnodelabel(tree->left, 1);
			findleafnodelabel(tree->right, 0);
		}
		else
		{
			tree->label = val;
		}
	}

	void findinteriornodelabel(node *tree)
	{
		if (tree->left->label == -1)
			findinteriornodelabel(tree->left);
		else if (tree->right->label == -1)
			findinteriornodelabel(tree->right);

		else
		{
			if (tree->left->label > tree->right->label)
				tree->label = tree->left->label;
			if (tree->right->label > tree->left->label)
				tree->label = tree->right->label;
			if (tree->left->label == tree->right->label)
				tree->label = tree->left->label + 1;
		}
	}

	void insertnode(node **tree, char c)
	{
		if (!(*tree))
		{
			node *temp = new node;
			temp->data = c;
			temp->left = temp->right = NULL;
			temp->label = -1;
			*tree = temp;
		}
	}

	void insert(node **tree, char c)
	{
		char l, r;
		int no_children;

		insertnode(tree, c);

		cout<<"Enter number of children of "<<c<<": ";
		cin>>no_children;
		if (no_children == 2)
		{
			cout<<"Enter left child of "<<c<<": ";
			cin>>l;
			insertnode(&(*tree)->left, l);

			cout<<"Enter right child of "<<c<<": ";
			cin>>r;
			insertnode(&(*tree)->right, r);

			insert(&(*tree)->left, l);
			insert(&(*tree)->right, r);
			
		}
	}

	void push(int val)
	{
		top++;
		R[top] = val;
	}

	int pop()
	{
		int temp = R[top];
		top--;
		return temp;
	}

	void inorder(node *tree)
	{
		if (tree)
		{
			inorder(tree->left);
			cout<<tree->data<<" with label "<<tree->label<<endl;
			inorder(tree->right);
		}
	}

	void deltree(node *tree)
	{
		if (tree)
		{
			deltree(tree->left);
			deltree(tree->right);
			delete tree;
		}
	}

	void nameofoperation(char c)
	{
		switch(c)
		{
			case '+': op = (char*)"ADD"; break;
			case '-': op = (char*)"SUB"; break;
			case '*': op = (char*)"MUL"; break;
			case '/': op = (char*)"DIV"; break;
		}
	}

	void gencode(node  *tree)
	{
		if (tree->left != NULL && tree->right != NULL)
		{
			if (tree->left->left != NULL && tree->left->right != NULL && tree->right->left != NULL && tree->right->right != NULL && tree->left->label == 1 && tree->right->label == 0)
			{
				cout<<"MOV "<<tree->left->data<<", R["<<R[top]<<"]"<<endl;
				nameofoperation(tree->data);
				cout<<op<<" "<<tree->right->data<<", R["<<R[top]<<"]"<<endl;
			}

			if (tree->left->label >= 1 && tree->right->label == 0)
			{
				gencode(tree->left);
				nameofoperation(tree->data);
				cout<<op<<" "<<tree->right->data<<", R["<<top<<"]"<<endl;
			}

			else if (tree->right->label > tree->left->label)
			{
				int temp;
				swap();
				gencode(tree->right);
				temp = pop();
				gencode(tree->left);
				push(temp);
				swap();
				nameofoperation(tree->data);
				cout << op << " " << "R[" << R[top-1] <<"],R[" << R[top] << "]\n";
			}

			else if (tree->left->label >= tree->right->label)
			{
				gencode(tree->left);
				int temp = pop();
				gencode(tree->right);
				push(temp);
				nameofoperation(tree->data);
				cout << op << " " << "R[" << R[top-1] << "],R[" << R[top] <<"]\n";
			}
		}
		else if (tree->left == NULL && tree->right == NULL && tree->label == 1)
		{
			cout<<"MOV "<<tree->data<<", R["<<R[top]<<"]"<<endl;
		}
	}
};

int main()
{
	dag obj;
	char c;
	node *root = NULL;
	cout<<"Enter root: ";
	cin>>c;
	obj.insert(&root, c);
	obj.findleafnodelabel(root, 1);
	while (root->label == -1)
		obj.findinteriornodelabel(root);
	obj.init_stack(root);
	cout<<"Inorder display:"<<endl;
	obj.inorder(root);
	cout<<"Assembly Code:"<<endl;
	obj.gencode(moot);
	obj.deltree(root);
	return 0;
}
