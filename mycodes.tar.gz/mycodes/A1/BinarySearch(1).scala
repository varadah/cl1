object BinarySearch{
// A Singleton class - Equivalent to static in java - (A class with a single instance (or simply an object_)) 

	def Search(nos : Array[Int], num : Int) : Int = 
	{
		var left = 0
		var right = nos.length-1
		
		while(left<=right)
		{

			var mid  = (left + right)/2
			if(nos(mid) == num)
			{
				return mid
			}else if(nos(mid) > num)
			{
				right = mid - 1
			}else{
				left = mid + 1
			}
		}
		return -1
	}

	def main(args : Array[String])
	{
		println("Enter Number of Elements\n")
		var n = Console.readInt
		var nos = new Array[Int](n)
		var toFind : Int = 0
		var i = 0

		for(i <- 0 to n-1)
		{
			nos(i) = Console.readInt;
		}
		
		val sortedArray = nos.sorted
		
		println("\nEnter number to find\n")
		
		toFind = Console.readInt
		var index = Search(sortedArray,toFind)
		if( index != -1)
		{
			println("Found Element at position " + index)
		
		}else{
			println("Element Not Found")
		}
	}
}