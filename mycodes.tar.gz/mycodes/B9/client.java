import java.io.BufferedReader;
import java.io.*;
import java.net.*;
import java.util.*;
public class client {
	public static void  main(String[] args) {
		try{
			Console cnsl = System.console();
			Socket s=new Socket("",9998);
			PrintWriter pn=new PrintWriter(s.getOutputStream(),true);
			System.out.println("Type MESSAGE here");
			String get;
			do{
				get=cnsl.readLine();
				HuffmanCode cd= new HuffmanCode(get);
				pn.println(cd.getCode());
				System.out.print("Encrypted Message Sent\n");
			}while(get.compareTo("bye")!=0);	
			}catch(Exception e){
				e.printStackTrace();
			}
		}

}
