import java.io.BufferedReader;
import java.io.*;
import java.net.*;
public class server {
	static ServerSocket socket;
	public static void main(String[] args) {
		server s2=new server();
		try{
			socket=new ServerSocket(9998);
			while(true){
				Socket s=socket.accept();
				String get;
				BufferedReader b=new BufferedReader(new InputStreamReader(s.getInputStream()));
				while(true){
					get=b.readLine();
					if(get.equals("bye"))
						break;
					if(get!=null){
						System.out.println(get);
					}
				}
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}
