main()
{
int b;
if(b==7)
{
printf("hello");
b++;
b**;
}
}
