import json

def isattack(board, r, c):
	for i in range(r):
		if(board[r][c] == 1):
			return True
	i = r - 1
	j = c - 1
	while(i >= 0 and j >= 0):
		if(board[i][j] == 1):
			return True
		i = i - 1
		j = j - 1
	i = r - 1
	j = c + 1
	while(i >= 0 and j < 8):
		if(board[i][j] == 1):
			return True
		i = i - 1
		j = j + 1
	return False

def solve(board, r):
	i = 0
	while (i < 8):
		if(not isattack(board, r, i)):
			board[r][i] = 1;
		if(r == 7):
			return True
		else:
			if(solve(board, r+1)):
				return True
			else:
				board[r][i] = 0
		i = i + 1
	if (i == 8):
		return False

def printboard(board):
	for i in range(8):
		for j in range(8):
			if (board[i][j] == 0):
				print(".  "),
			else:
				print ("1  "),
			print("\n")

def underattack(col, queens):
	return col in queens or \
		any(abs(x - col) == len(queens) - i for i, x in enumerate(queens))


def solve2(n):
	solutions = [[]]
	for i in range(n):
		solutions = [solution + [i+1] for solution in solutions for i in range(BOARD_SIZE) if(not(underattack(i + 1, solution)))]
	return solutions

BOARD_SIZE = 8
board = [[0 for x in range(8)]for x in range(8)]

if __name__ == '__main__':
	data = []
	with open('input.json') as f:
		data = json.load(f)
	if(data['start'] < 0 or data['start'] > 7):
		print("Invalid input.")
		exit()
	board[0][data['start']] = 1
	if(solve(board, 1)):
		print("Queens problem solved")
		print("Board Configuration: ")
		print(board)
	else:
		print("Queens problem not solved.")
	solutions = solve2(BOARD_SIZE)
	print("Total number of solutions = ", len(solutions))
	for answer in solutions:
		print(list(enumerate(answer, start = 1)))
